# 任务与编排领域｜TODO、实施顺序与验收门禁

> 目标：把当前设计落成第一版真实可用模块，不重新发散架构。

---

# 1. P0｜文档落库

- [ ] 将本目录放入 Phase 3 正式领域目录
- [ ] 与“平台各领域约定”检查命名 / Contract / Error / Ref 兼容
- [ ] 标记旧 Phase 2 Task Control 语义：保留 / 替代 / 废弃
- [ ] 不直接复制 Phase 2 WorkItem / Claim 模型进入 v1

GO：领域边界 / API / 状态 / schema 不存在相互矛盾。

---

# 2. P0｜技术环境 Spike

当前基础：Node 20.20.1、npm 10.x、Intel Mac、8GB RAM。

验证：

- [ ] `sqlite3@6.x` 安装成功
- [ ] Intel Mac 加载正常；若 fallback build，记录环境要求
- [ ] open DB PASS
- [ ] transaction PASS
- [ ] WAL PASS
- [ ] restart PASS
- [ ] Ajv schema validation PASS

STOP：若 sqlite driver 在当前 Mac 不可稳定安装，不继续 Task 实现，重新评估 driver；不要因此轻易升级整个 Node major。

---

# 3. P0｜建立 3 个 npm 包骨架

- [ ] `@ai-agent-platform/task-orchestration`
- [ ] `@ai-agent-platform/task-store-sqlite`
- [ ] `@ai-agent-platform/task-migration-runner`

约束：task-orchestration 不直接写 SQL；task-store-sqlite 不拥有业务决策；task-migration-runner 不拥有 Task schema 语义。

---

# 4. P0｜Migration Runner

- [ ] migration discovery
- [ ] version ordering
- [ ] schema_migrations
- [ ] transaction execution
- [ ] duplicate apply prevention
- [ ] failure rollback
- [ ] verify current version

---

# 5. P0｜SQLite Store

实现：

- [ ] task_groups
- [ ] tasks
- [ ] nodes
- [ ] node_execution_history
- [ ] task_documents
- [ ] task_messages
- [ ] task_events
- [ ] idempotency_records
- [ ] schema_migrations

Repositories：

- [ ] TaskGroupRepository
- [ ] TaskRepository
- [ ] NodeRepository
- [ ] NodeExecutionHistoryRepository
- [ ] TaskDocumentRepository
- [ ] TaskMessageRepository
- [ ] TaskEventRepository
- [ ] IdempotencyRepository

---

# 6. P0｜Domain Service

## TaskCommandService

- [ ] createTaskGroup
- [ ] startTaskGroup
- [ ] createTask
- [ ] startTask
- [ ] pauseTask
- [ ] resumeTask
- [ ] terminateTask
- [ ] startNode
- [ ] completeNode
- [ ] waitNode
- [ ] failNode
- [ ] reopenNode
- [ ] acknowledgeMessage

## TaskQueryService

- [ ] getTaskGroup
- [ ] listTasks
- [ ] getTask
- [ ] getNodeContext
- [ ] listPendingMessages
- [ ] listTaskEvents

## TaskDocumentService

- [ ] putTaskDocument
- [ ] getTaskDocument
- [ ] readDocumentsForNode
- [ ] verifyRequiredOutputs
- [ ] safe path mapping
- [ ] atomic write
- [ ] contentHash
- [ ] reconciliation

---

# 7. P0｜Contract / Schema

- [ ] success envelope
- [ ] error envelope
- [ ] API input JSON Schema
- [ ] API output JSON Schema
- [ ] TaskStatus enum
- [ ] NodeStatus enum
- [ ] TaskGroupStatus enum
- [ ] waitType enum
- [ ] documentType baseline
- [ ] error code baseline
- [ ] opaque ref field rules

---

# 8. P0｜状态机测试

至少覆盖：

```text
Task:
PENDING → READY
READY → ACTIVE
ACTIVE → WAITING
WAITING → ACTIVE
ACTIVE → PAUSED
PAUSED → ACTIVE
ACTIVE → FAILED
ACTIVE → SUCCEEDED
* → TERMINATED（按合法规则）

Node:
PENDING → READY
READY → IN_PROGRESS
IN_PROGRESS → SUCCEEDED
IN_PROGRESS → WAITING
WAITING → IN_PROGRESS
IN_PROGRESS → FAILED
SUCCEEDED / FAILED / WAITING → reopen semantics
```

非法状态变更必须 zero side effect。

---

# 9. P0｜并发 / 幂等测试

- [ ] stale Task version
- [ ] stale Node version
- [ ] double startTask
- [ ] double startNode
- [ ] double completeNode
- [ ] double reopenNode
- [ ] same idempotency key / same hash
- [ ] same key / different hash
- [ ] Node worker mismatch
- [ ] paused task rejects progression

---

# 10. P0｜reopen 测试矩阵

至少：

```text
A SUCCEEDED
B SUCCEEDED
C WAITING
D PENDING

reopen B
→ B READY runNo+1
→ C PENDING
→ D PENDING
→ old B/C history preserved
→ Task ACTIVE
→ currentNodeId = B
```

再测试 reopen current FAILED Node、reopen first Node、reopen invalid Node、reopen with stale version。

---

# 11. P0｜Task Document 测试

- [ ] initial requirement write
- [ ] documentType → safe path
- [ ] path traversal rejected
- [ ] getNodeContext only returns declared input docs
- [ ] completeNode missing output rejected
- [ ] output present complete PASS
- [ ] Git tracked Markdown usable
- [ ] SQLite index matches hash
- [ ] DB update failure after file write can reconcile

---

# 12. P0｜TaskGroup 测试

```text
TG READY → startTaskGroup → ACTIVE
Task1 READY / ACTIVE / SUCCEEDED → Task2 eligibility true
Task1 WAITING → Task2 cannot start
Task1 FAILED → Task2 cannot start
Task1 PAUSED → Task2 cannot start
```

---

# 13. P1｜Gateway Adapter

领域包通过现有 Gateway 暴露稳定 API。

要求：Gateway 是 Adapter，不拥有 Task 状态；HTTP error != domain error；domain contract version preserved。

不要一开始把 21 个 Public API 全部平铺成 21 个 GPT Actions。

---

# 14. P1｜Browser Extension Adapter

最小需求：`listTasks / listPendingMessages / startTask / startNode`。

扩展负责 UI / Browser，但 `canStart / blockedReason` 由 Task Domain 给出，扩展不复制业务规则。

---

# 15. P1｜Agent Domain Integration

Agent Domain 根据 `requiredRoleRef` 选择具体 `workerRef`；Task Domain 用 `startNode` 记录 workerRef。

验证：Role 不是全局锁；同 Role 的不同 Worker 可以处理不同 Task；Task 不读取 Agent Session 内部状态。

---

# 16. P1｜真实 dogfooding

第一版通过内部测试后，用它继续推进 `ai-agent-platform` Phase 3 自身。

真实 Task 至少覆盖 Requirement、Product / Design、Development、Test、WAITING、reopen、Resume、TaskGroup chain、Markdown context。

---

# 17. GO 门

跨领域接线前必须：

```text
Contract tests PASS
SQLite migration PASS
state transition PASS
transaction crash tests PASS
idempotency PASS
reopen history PASS
document context PASS
TaskGroup gating PASS
current Mac deploy/verify PASS
```

---

# 18. STOP 门

出现以下任一情况停止继续堆功能：

```text
需要重新引入 WorkItem / Claim 才能跑通基础主链
需要 Redis / Queue 才能完成单机主链
需要 Node 22 才能运行选定依赖
Task / Node 当前状态出现双真源
reopen 会覆盖历史
文档正文同时以 DB + Markdown 双真源存在
扩展需要自行复制 Task eligibility 规则
```

先回架构文档解决。

---

# 19. 暂缓

```text
并行 Node
通用 DAG
Condition Edge
通用循环
Worker reassignment
Claim Lease
distributed queue
multi-host Task scheduler
Event sourcing
跨 Task Knowledge RAG
WebSocket push
复杂 RBAC
复杂 Document Version Service
```
